# php artisan migrate && php artisan db:seed && php artisan serve
composer install && php artisan serve
